#pragma once

#ifdef __cplusplus
extern "C" {
#endif

int add_integers(int i, int j);
int subtract_integers(int i, int j);

#ifdef __cplusplus
}
#endif
